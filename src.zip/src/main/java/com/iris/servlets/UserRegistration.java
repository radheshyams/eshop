package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.model.User;
import com.iris.Dao.UserDao;
import com.iris.DaoImpl.UserDaoImpl;


@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public UserRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		UserDao dobj=new UserDaoImpl();
		User u=new User();
		String s1=request.getParameter("uid");
		int a=Integer.parseInt(s1);
		u.setUserId(a);
		u.setUserName(request.getParameter("uname"));
		u.setPassword(request.getParameter("password"));
		u.setGender(request.getParameter("gender"));
		u.setEmail(request.getParameter("email"));
		u.setCity(request.getParameter("city"));
		u.setRole(request.getParameter("role"));
		System.out.println(u);
		
		boolean r = false;
		try {
			r = dobj.registerUser(u);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(r==true){
			RequestDispatcher rd=request.getRequestDispatcher("UserRegister.jsp");
			rd.forward(request, response);
		}
		else {
		out.println("Problem in Adding Customer");
		RequestDispatcher rd=request.getRequestDispatcher("Register.jsp");
		rd.include(request, response);
		
		}
		
	}
		
	}



