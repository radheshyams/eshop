package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.iris.Dao.UserDao;
import com.iris.DaoImpl.UserDaoImpl;
import com.iris.model.Address;
import com.iris.model.User;

@WebServlet("/AddAdress")
public class AddAdress extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AddAdress() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		UserDao dObj= new UserDaoImpl(); 
		
		String s1=request.getParameter("addr1");
		String s2=request.getParameter("addr2");
		
		Address addr=new Address();
		addr.setAddr1(s1);
		addr.setAddr2(s2);
		HttpSession session=request.getSession();
		User Obj=(User)session.getAttribute("custObj");
		Set<Address> addrSet=Obj.getAddrset();
		addrSet.add(addr);
		Obj.setAddrset(addrSet);
			boolean r=false;	
		try {
			r=dObj.updateUser(Obj);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		if(r==true)
		{
			session.setAttribute("cObj", Obj);
			RequestDispatcher rd= request.getRequestDispatcher("UserDetail.jsp");
			
		}
		
		
	}

}
