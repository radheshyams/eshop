package com.iris.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.iris.DaoImpl.UserDaoImpl;
import com.iris.model.User;
import com.iris.Dao.UserDao;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		UserDao daoObj=new UserDaoImpl();
	
		String s1=request.getParameter("uid");
		int a=Integer.parseInt(s1);
		String s2=request.getParameter("password");
		User cust = null;
		try {
			cust = daoObj.validateUser(a,s2);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		if(cust!=null){
			
            HttpSession session=request.getSession();
            session.setAttribute("custObj", cust);
            if(cust.getRole().equals("Admin"))
            {
                  RequestDispatcher rd1=request.getRequestDispatcher("Admin.jsp");
                  rd1.forward(request, response);
            }
            else if(cust.getRole().equals("customer"))
            {
                  RequestDispatcher rd1=request.getRequestDispatcher("UserDetail.jsp");
                  rd1.forward(request, response);
            }
     }

		else {
			out.println("<div style='color:red;'>Wrong ID or Password</div>");
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			rd.include(request, response);
		}
	}

}
