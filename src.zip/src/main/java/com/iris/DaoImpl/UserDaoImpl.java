package com.iris.DaoImpl;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.iris.Dao.UserDao;
import com.iris.model.User;
import com.iris.utility.SessionFactoryProvider;

public class UserDaoImpl implements UserDao {
	SessionFactory sf=SessionFactoryProvider.getSessionFactory();

	public boolean registerUser(User obj) throws Exception {
		try {
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			session.save(obj);
			tx.commit();
			session.close();
			return true;
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return false;
		
		
	}

	public User getUser(int userId) throws Exception {
		try {
			Session session=sf.openSession();
			User obj=session.get(User.class,userId);
			session.close();
			return obj;
			}
			catch(Exception e){
				e.printStackTrace();
			}
		return null;
	
	}
	public User validateUser(int userId, String password) {
        try {
            Session session = sf.openSession();
            User obj = session.get(User.class, userId);
            if(obj==null) {
                            return null;
            }
            else {
                            String s1=obj.getPassword();
                            if(s1.equals(password))
                            {
                            			session.close();
                                            return obj;
                            }
            }
            session.close();
            return obj;

            } catch (Exception e) {
                            e.printStackTrace();
            }

            return null;

		
		
	}


	public List<User> getAllUser() throws Exception {
            	try {
                            Session session = sf.openSession();
                            Query<User> query=session.createQuery("from com.iris.model.User");
                           
                            List<User> userList = query.list();
                            session.close();
                            return userList;
            } catch (Exception e) {
                            e.printStackTrace();
            }

            return null;
}
    public boolean deleteUser(int id) {
        try {

                        Session session = sf.openSession();
                        Transaction tx = session.beginTransaction();
                        User obj = session.get(User.class, id);

                        if (obj == null) {
                                        return false;
                        } else {
                                        session.delete(obj);
                        }
                        tx.commit();
                        session.close();

        } catch (Exception e) {
                        e.printStackTrace();
        }
        return true;

}

    			public boolean updateUser(User cust) {
    					try {

                        Session session = sf.openSession();
                        Transaction tx = session.beginTransaction();
                        session.update(cust);
                        tx.commit();
                        session.close();

        } catch (Exception e) {
                        e.printStackTrace();
        }
        return false;

}
public User updateForm(int id) {
    
    try {
    Session session = sf.openSession();
    User obj = session.get(User.class, id);
    session.close();
    return obj;

    } catch (Exception e) {
                    e.printStackTrace();
    }

    return null;
}

	
}


	

