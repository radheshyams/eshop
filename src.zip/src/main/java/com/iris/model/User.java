package com.iris.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

@Entity
@Table(name="User_Eshop")
public class User {
	@Id
	private int userId;
	private String userName;
	private String gender;
	private String email;
	private String password;
	private String city;
	private String role="customer";
	
	
	@ElementCollection(fetch=FetchType.EAGER)
	@JoinTable(name="UserAddress",joinColumns=@JoinColumn(name="userId"))
	private Set<Address> addrset=new HashSet<Address>();
	
	
	
	public Set<Address> getAddrset() {
		return addrset;
	}

	public void setAddrset(Set<Address> addrset) {
		this.addrset = addrset;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", gender=" + gender + ", email=" + email
				+ ", password=" + password + ", city=" + city + ", role=" + role + ", addrset=" + addrset + "]";
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	

}
