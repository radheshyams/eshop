package com.iris.Dao;

import java.util.List;

import com.iris.model.User;

public interface UserDao {
	public boolean registerUser(User obj)throws Exception;
	public User getUser(int userId)throws Exception;
	public List<User> getAllUser()throws Exception;
	public User validateUser(int id, String password)throws Exception;
	public boolean deleteUser(int id)throws Exception;
	public boolean updateUser(User cust)throws Exception;
	public User updateForm(int id)throws Exception;


}
