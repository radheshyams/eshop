package com.iris.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iris.Dao.UserDao;
import com.iris.DaoImpl.UserDaoImpl;
import com.iris.model.User;

/**
* Servlet implementation class Updated
*/
@WebServlet("/Updated")
public class Updated extends HttpServlet {
       private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updated() {
        super();
        // TODO Auto-generated constructor stub
    }

       /**
       * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
       */
       protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              // TODO Auto-generated method stub
              response.getWriter().append("Served at: ").append(request.getContextPath());
       }

       /**
       * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
       */
       protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              response.setContentType("text/html");
              PrintWriter out=response.getWriter();
       UserDao daoObj=new UserDaoImpl();
       String s1=request.getParameter("id");
       int n=Integer.parseInt(s1);
       String s2=request.getParameter("name");
       String s3=request.getParameter("password");
       String s4=request.getParameter("gender");
       String s5=request.getParameter("email");
       String s6=request.getParameter("city");
       

       User Obj=new User(); 
       Obj.setUserName(s2);
       Obj.setPassword(s3);
       Obj.setEmail(s5);
       Obj.setCity(s6);
       Obj.setGender(s4);
       Obj.setUserId(n);
       
       boolean a=false;
       try {
              a=daoObj.updateUser(Obj);
       } catch (Exception e) {
              // TODO: handle exception
              e.printStackTrace();
       }
              if(a==true)
       {
                     out.println("Data Updated");
                     RequestDispatcher rd=request.getRequestDispatcher("ViewAll");
                     rd.include(request, response);
       }
       else
              {out.println("Data not Updated");}
       }

}
